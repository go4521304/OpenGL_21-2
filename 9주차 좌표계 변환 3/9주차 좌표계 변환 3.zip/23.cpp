#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <random>
#include <cmath>
#include <random>

#include <gl/glew.h> // �ʿ��� ������� include
#include <gl/freeglut.h>
#include <gl/freeglut_ext.h>
#include <gl/glm/glm.hpp>
#include <gl/glm/ext.hpp>
#include <gl/glm/gtc/matrix_transform.hpp>

using namespace std;

const float moveVal = 0.01f;
const int angleVal = 1;

int SCR_WIDTH = 1200, SCR_HEIGHT = 800;

void convert_glpos(int x, int y, float& new_X, float& new_Y)
{
	int w = glutGet(GLUT_WINDOW_WIDTH), h = glutGet(GLUT_WINDOW_HEIGHT);

	new_X = (float)((x - (float)w / 2.0) * (float)(1.0 / (float)(w / 2.0)));
	new_Y = -(float)((y - (float)h / 2.0) * (float)(1.0 / (float)(h / 2.0)));
}

char* filetobuf(const char* file)
{
	ifstream in{ file };

	if (!in.is_open())
		return NULL;

	string s(istreambuf_iterator<char>{in}, {});

	char* str = new char[s.size() + 1];
	copy(s.begin(), s.end(), str);
	str[s.size()] = '\0';

	return str;
}

// 1,0,2, 1,2,3, 0,4,6, 0,6,2, 5,1,3, 5,3,7, 4,5,7, 4,7,6, 5,4,0, 5,0,1, 3,2,6, 3,6,7
// �� �� �� �� �� �Ʒ�
glm::vec3 Cube[] = {
	{-0.5f, +0.5f, +0.5f},
	{+0.5f, +0.5f, +0.5f},
	{-0.5f, -0.5f, +0.5f},
	{+0.5f, -0.5f, +0.5f},
	{-0.5f, +0.5f, -0.5f},
	{+0.5f, +0.5f, -0.5f},
	{-0.5f, -0.5f, -0.5f},
	{+0.5f, -0.5f, -0.5f}
};

GLvoid drawScene();
GLvoid Reshape(int w, int h);

void make_vertexShader();
void make_fragmentShader();
void set_vert();
void InitBuffer();
void InitShader();

void Keyboard(unsigned char key, int x, int y);
void KeyboardUp(unsigned char key, int x, int y);
void MouseClick(int button, int state, int x, int y);
void Mouse(int x, int y);

void Animate(int val);

GLuint vertexShader, fragmentShader; //--- ���̴� ��ü
GLuint s_program;

GLuint vao, vbo;

glm::vec3 cameraTarget = { 0.0f, 0.0f, 0.0f };
float cameraAngle = 0.0f;

bool isCamMoveX = false, isCamMoveY = false, isCamMoveZ = false, isCamRotate = false;
float camXdir = -1.0f, camZdir = -1.0f, camRotatedir = -1.0f;

const glm::vec3 cubeColor[] = { {1.0f, 0.87f, 0.93}, {0.87f, 0.93f, 1.0f}, {0.87f, 1.0f, 0.87f}, {0.8f, 0.8f, 0.8f}, {1.0f, 0.87f, 0.93}, {1.0f, 1.0f, 1.0f} };

bool isMouseClick = false;
float pastXpos = 0.0f;
int boxAngle = 0;
glm::vec3 smallBoxPos[3] = { {0.0f, -0.85f, -0.5}, {0.0f, -0.9f, 0.0f}, {0.0f, -0.95f, 0.5f} };
glm::vec3 smallBoxScale[3] = { { 0.3f, 0.3f, 0.3f } , { 0.2f, 0.2f, 0.2f } ,{ 0.1f, 0.1f, 0.1f } };

struct ball
{
	glm::vec3 position = { 0.0f, 0.0f, 0.0f };
	glm::vec3 direction = { 0.0f, 0.0f, 0.0f };
	bool active = false;
};

ball balls[5] = {
	{{0.3f, -0.1f, 0.7f}, {-1.0f, 2.0f, 1.0f}, false},
	{{-0.5f, 0.0f, 0.1f}, {-2.0f, 3.0f, 1.0f}, false},
	{{-0.25f, 0.3f, 0.6f}, {1.0f, 1.0f, -2.0f}, false},
	{{0.0f, -0.7f, 0.5f}, {1.0f, -4.0f, 2.0f}, false},
	{{0.0f, 0.1f, 0.7f}, {5.0f, 5.0f, 5.0f}, false}
};

int main(int argc, char** argv) //--- ������ ����ϰ� �ݹ��Լ� ����
{
	//--- ������ �����ϱ�
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowPosition(10, 10);
	glutInitWindowSize(SCR_WIDTH, SCR_HEIGHT);
	glutCreateWindow("Practice23");

	//--- GLEW �ʱ�ȭ�ϱ�
	glewExperimental = GL_TRUE;
	if (glewInit() != GLEW_OK)		// glew �ʱ�ȭ
	{
		std::cerr << "Unable to initialize GLEW" << std::endl;
		exit(EXIT_FAILURE);
	}
	else
	{
		std::cout << "GLEW Initialized\n\n";
		cout << "X: ī�޶� x�� ���� �̵�" << endl;
		cout << "Z: ī�޶� Z�� ���� �̵�" << endl;
		cout << "Y: ī�޶� ȭ���߽� ���� Y�� ȸ��" << endl;
		cout << "Q: ����" << endl;
	}

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);

	InitShader();
	InitBuffer();

	glutDisplayFunc(drawScene);
	glutReshapeFunc(Reshape);
	glutKeyboardFunc(Keyboard);
	glutKeyboardUpFunc(KeyboardUp);
	glutMouseFunc(MouseClick);
	glutMotionFunc(Mouse);
	glutTimerFunc(10, Animate, 0);
	glutMainLoop();
}

//--- �׸��� �ݹ� �Լ�
GLvoid drawScene()
{
	//--- ����� ���� ����
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glUseProgram(s_program);
	glBindVertexArray(vao);

	unsigned int pView = glGetUniformLocation(s_program, "view");
	unsigned int pProj = glGetUniformLocation(s_program, "proj");
	unsigned int pModel = glGetUniformLocation(s_program, "model");
	unsigned int PColor = glGetUniformLocation(s_program, "vColor");

	glm::mat4 m_view = glm::mat4(1.0f);
	glm::mat4 m_proj = glm::mat4(1.0f);
	glm::mat4 m_model = glm::mat4(1.0f);

	glViewport(0, 0, SCR_WIDTH, SCR_HEIGHT);

	glm::vec3 cameraPos = { 5.0f * glm::sin(glm::radians(cameraAngle)), 0.0f, 5.0f * glm::cos(glm::radians(cameraAngle)) };
	cameraPos += cameraTarget;
	glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

	m_view = glm::lookAt(cameraPos, cameraTarget, cameraUp);
	m_proj = glm::perspective(glm::radians(45.0f), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);

	glUniformMatrix4fv(pView, 1, GL_FALSE, glm::value_ptr(m_view));
	glUniformMatrix4fv(pProj, 1, GL_FALSE, glm::value_ptr(m_proj));

	m_model = glm::rotate(m_model, glm::radians((float)boxAngle), { 0.0f, 0.0f, 1.0f });
	glm::mat4 m_box = glm::mat4(1.0f);
	m_box = glm::scale(m_box, { 2.0f, 2.0f, 2.0f });
	m_box = m_model * m_box;
	glUniformMatrix4fv(pModel, 1, GL_FALSE, glm::value_ptr(m_box));

	for (int i = 0; i < 6; ++i)
	{
		glUniform3f(PColor, cubeColor[i].r, cubeColor[i].g, cubeColor[i].b);
		glDrawArrays(GL_TRIANGLES, i * 6, 6);
	}

	glUniform3f(PColor, 1.0f, 0.0f, 0.0f);
	for (int i = 0; i < 3; ++i)
	{
		glm::mat4 m_smallBox = glm::mat4(1.0f);
		m_smallBox = glm::translate(m_smallBox, smallBoxPos[i]);
		m_smallBox = glm::scale(m_smallBox, smallBoxScale[i]);
		m_smallBox = glm::rotate(m_smallBox, glm::radians((float)boxAngle), { 0.0f, 0.0f, 1.0f });
		glUniformMatrix4fv(pModel, 1, GL_FALSE, glm::value_ptr(m_smallBox));
		glDrawArrays(GL_TRIANGLES, 36, 36);
	}
	
	/*
	glm::mat4 m_smallBox2 = glm::mat4(1.0f);
	m_smallBox2 = glm::translate(m_smallBox2, { (1.0f / 60.0f) * boxAngle * 0.9f * -1, -1.0f + 0.1f, 0.0f });
	m_smallBox2 = glm::scale(m_smallBox2, );
	m_smallBox2 = m_model * m_smallBox2;
	glUniformMatrix4fv(pModel, 1, GL_FALSE, glm::value_ptr(m_smallBox2));
	glDrawArrays(GL_TRIANGLES, 36, 36);

	glm::mat4 m_smallBox3 = glm::mat4(1.0f);
	m_smallBox3 = glm::translate(m_smallBox3, { (1.0f / 60.0f) * boxAngle * 0.95f * -1, -1.0f + 0.05f, 0.5f });
	m_smallBox3 = glm::scale(m_smallBox3, );
	m_smallBox3 = m_model * m_smallBox3;
	glUniformMatrix4fv(pModel, 1, GL_FALSE, glm::value_ptr(m_smallBox3));
	glDrawArrays(GL_TRIANGLES, 36, 36);
	*/
	glUniform3f(PColor, 0.0f, 0.0f, 1.0f);
	GLUquadricObj* planet = gluNewQuadric();

	glm::mat4 m_ball;
	for (int i = 0; i < 5; ++i)
	{
		if (balls[i].active == true)
		{
			m_ball = glm::mat4(1.0f);
			m_ball = glm::translate(m_ball, balls[i].position);
			m_ball = m_model * m_ball;
			glUniformMatrix4fv(pModel, 1, GL_FALSE, glm::value_ptr(m_ball));
			gluSphere(planet, 0.03, 20, 20);
		}
	}

	glutSwapBuffers(); //--- ȭ�鿡 ����ϱ�
}

GLvoid Reshape(int w, int h)		//--- �ݹ� �Լ�: �ٽ� �׸��� �ݹ� �Լ�
{
	SCR_WIDTH = w;
	SCR_HEIGHT = h;
}


/******************************���̴� ���α׷� �����*************************************/
/**************************************************************************************/
void make_vertexShader()
{
	GLchar* vertexSource = filetobuf("vertex_pr18.vert");

	//--- ���ؽ� ���̴� ��ü �����
	vertexShader = glCreateShader(GL_VERTEX_SHADER);

	//--- ���̴� �ڵ带 ���̴� ��ü�� �ֱ�
	glShaderSource(vertexShader, 1, (const GLchar**)&vertexSource, 0);

	//--- ���ؽ� ���̴� �������ϱ�
	glCompileShader(vertexShader);

	//--- �������� ����� ���� ���� ���: ���� üũ
	GLint result;
	GLchar errorLog[512];
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &result);

	if (!result)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, errorLog);
		cerr << "ERROR: vertex shader ������ ����\n" << errorLog << endl;
		return;
	}
}
void make_fragmentShader()
{
	GLchar* fragmentSource = filetobuf("fragment_pr18.frag");

	//--- �����׸�Ʈ ���̴� ��ü �����
	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);

	//--- ���̴� �ڵ带 ���̴� ��ü�� �ֱ�
	glShaderSource(fragmentShader, 1, (const GLchar**)&fragmentSource, 0);

	//--- �����׸�Ʈ ���̴� ������
	glCompileShader(fragmentShader);

	//--- �������� ����� ���� ���� ���: ������ ���� üũ
	GLint result;
	GLchar errorLog[512];
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &result);
	if (!result)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, errorLog);
		cerr << "ERROR: fragment shader ������ ����\n" << errorLog << endl;
		return;
	}
}

void InitShader()
{
	make_vertexShader(); //--- ���ؽ� ���̴� �����
	make_fragmentShader(); //--- �����׸�Ʈ ���̴� �����

	//-- shader Program
	s_program = glCreateProgram();

	glAttachShader(s_program, vertexShader);
	glAttachShader(s_program, fragmentShader);
	glLinkProgram(s_program);

	//--- ���̴� �����ϱ�
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);
}
/**************************************************************************************/
/**************************************************************************************/

void set_vert()
{
	const int cubeBackIndex[] = { 2,0,1, 3,2,1, 6,4,0, 2,6,0, 3,1,5, 7,3,5, 7,5,4, 6,7,4, 0,4,5, 1,0,5, 6,2,3, 7,6,3 };
	const int cubeIndex[] = { 1,0,2, 1,2,3, 0,4,6, 0,6,2, 5,1,3, 5,3,7, 4,5,7, 4,7,6, 5,4,0, 5,0,1, 3,2,6, 3,6,7 };

	vector<glm::vec3> vPos;
	for (const auto& i : cubeBackIndex)
	{
		vPos.push_back(Cube[i]);
	}

	for (const auto& i : cubeIndex)
	{
		vPos.push_back(Cube[i]);
	}

	glBindVertexArray(vao);

	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, vPos.size() * sizeof(glm::vec3), vPos.data(), GL_STATIC_DRAW);
	GLint pAttribute = glGetAttribLocation(s_program, "vPos");
	glVertexAttribPointer(pAttribute, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), 0);
	glEnableVertexAttribArray(pAttribute);
}

void InitBuffer()
{
	glGenVertexArrays(1, &vao);
	glGenBuffers(1, &vbo);
	set_vert();
}

void Keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'X':
	case 'x':
		isCamMoveX = true;
		break;

	case 'Y':
	case 'y':
		isCamRotate = true;
		break;

	case 'Z':
	case 'z':
		isCamMoveZ = true;
		break;

	case 'b':
	case 'B':
		for (int i = 0; i < 5; ++i)
			if (balls[i].active == false)
			{
				balls[i].active = true;
				break;
			}
		break;

	case 'Q':
	case 'q':
		std::cout << "Bye Bye~!" << std::endl;
		glutLeaveMainLoop();
		exit(0);
		break;
	}
}

void KeyboardUp(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'X':
	case 'x':
		isCamMoveX = false;
		camXdir *= -1.0f;
		break;

	case 'Y':
	case 'y':
		isCamRotate = false;
		camRotatedir *= -1.0f;
		break;

	case 'Z':
	case 'z':
		isCamMoveZ = false;
		camZdir *= -1.0f;
		break;
	}
}

void MouseClick(int button, int state, int x, int y)
{
	if (button == GLUT_LEFT_BUTTON)
	{
		if (state == GLUT_DOWN)
		{
			isMouseClick = true;
			pastXpos = x;
		}
		else if (state == GLUT_UP)
			isMouseClick = false;
	}
}
void Mouse(int x, int y)
{
	if (x > pastXpos && boxAngle > -60)
		boxAngle -= angleVal;
	else if (x <= pastXpos && boxAngle < 60)
		boxAngle += angleVal;
}

void Animate(int val)
{
	if (isCamMoveX)
	{
		cameraTarget.x += camXdir * moveVal;
	}
	if (isCamMoveZ)
	{
		cameraTarget.z += camZdir * moveVal;
	}
	if (isCamRotate)
	{
		cameraAngle += camRotatedir;
	}

	for (int i = 0; i < 5; ++i)
	{
		if (balls[i].active == true)
		{
			balls[i].position += balls[i].direction * moveVal;

			if (1.0f <= balls[i].position.x || -1.0f >= balls[i].position.x)
				balls[i].direction.x *= -1;
			if (1.0f <= balls[i].position.y || -1.0f >= balls[i].position.y)
				balls[i].direction.y *= -1;
			if (1.0f <= balls[i].position.z || -1.0f >= balls[i].position.z)
				balls[i].direction.z *= -1;
		}
	}

	for (int i = 0; i < 3; ++i)
	{
		glm::vec3 pastPos = smallBoxPos[i];

		if (boxAngle > 0)
		{
			smallBoxPos[i].x -= moveVal;
		}
		else if (boxAngle < 0)
		{
			smallBoxPos[i].x += moveVal;
		}
		
	}
	 

	glutTimerFunc(10, Animate, 0);
	glutPostRedisplay();
}